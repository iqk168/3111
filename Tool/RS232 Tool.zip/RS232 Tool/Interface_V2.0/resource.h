//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Interface.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_INTERFACE_DIALOG            102
#define ID_TIME_STATUS                  102
#define IDR_MAINFRAME                   128
#define IDI_CLEAR                       156
#define IDI_SEND                        173
#define IDI_DISCONNECT                  200
#define IDI_CONNECT                     201
#define IDC_COM_PORT                    1001
#define IDC_BAUD_RATE                   1002
#define IDC_DATA_BIT                    1003
#define IDC_PARITY_CHECK                1004
#define IDC_STOP_BIT                    1005
#define IDC_CONNECT                     1006
#define IDC_SEND_TEXT                   1007
#define IDC_SEND                        1008
#define IDC_SHOW_TEXT                   1009
#define IDC_CLEAR                       1010
#define IDC_SHOW_CODE                   1011
#define IDC_SHOW_NUMERIC                1012
#define IDC_SEND_TEXT2                  1013
#define IDC_CODE                        1014
#define IDC_CODE2                       1015
#define IDC_SEND2                       1016
#define IDC_SEND3                       1017
#define IDC_CODE_COUNT                  1019
#define IDC_VALUE                       1020
#define IDC_SET                         1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
